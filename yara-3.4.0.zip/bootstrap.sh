#!/bin/sh
autoreconf --force --install
